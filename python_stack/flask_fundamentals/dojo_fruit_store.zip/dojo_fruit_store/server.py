from flask import Flask, render_template, request, redirect
from datetime import datetime
app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
	datetimenow = datetime.now()
	sumTotal = int(request.form['strawberry']) + int(request.form['raspberry']) + int(request.form['apple'])
	return render_template("checkout.html", sumTotal = sumTotal, datetimenow = datetimenow)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")


app.run(debug=True)    