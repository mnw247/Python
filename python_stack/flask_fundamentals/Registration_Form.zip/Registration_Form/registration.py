from flask import Flask, render_template, request, redirect, session, flash
app = Flask(__name__) 
app.secret_key = 'secrets' 

@app.route('/')  
def index():
    return render_template("registration.html")


@app.route('/process', methods=['POST'])
def process():
	noblank()
	fnln()
	passcheck()

	return redirect('/')

def noblank():
	if len(request.form.get('first_name', "")) < 1:
		flash ('Needs first name!')
	# else:
	# 	flash("Success! Your name is " + request.form['first_name'])

	if len(request.form.get('last_name', "")) < 1:
		flash ('Needs last name!')
	# else:
	# 	flash("Success! Your name is " + request.form['last_name'])
	
	if len(request.form.get('email', "")) < 1:
		flash ('Needs email!')
	# else:
	# 	flash("Success! Your email is " + request.form['email'])

	if len(request.form.get('password', "")) < 1:
		flash ('Needs a password!')


def fnln():
	if not request.form.get('first_name', "").isalpha():
		flash ('First Name is not Valid, alphabet characters only!')
	if not request.form.get('last_name', "").isalpha():
		flash ('Last Name is not Valid, alphabet characters only!')

def passcheck():
	if len(request.form.get('password', "")) < 8:
		flash ('Invalid Password! Must have at least 8 characters')
	if request.form.get('password') != request.form.get('verifypass'):
		flash ('Password Confirmation does not match Password!')
	# elif len(request.form.get('password', "")) >= 8:
	# 	flash ("Success you have a Password")

app.run(debug=True)